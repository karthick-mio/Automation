# Ansible Workflow for Create a storage account, Check server connectivity, cluster configuration and Create & configure availability group with listener configuration.

## Introduction:

This workflow mainly for creating and configuring availability group with listener which will be done in different roles by creating storage account with cluster quorom witness and to check cluster configuration.

## Table of contents:
1. Goals and objective.
2. Operational Overview

## Goals and Objective:
The main goal is to create and configure availability group by using following configurations,
- Cluster Configuration: Ensure Server information from CMP
- Storage Configuration: Create storage account for file sharing
- Sql Server Configuration: Setting up Cluster and DB configuration
- Sql ag Configuration: Creating Availability and set configuration.

## Operation Overview:
Roles used in this workflow, 
    - windows-cluster
    - storage-cluster
    - sql-cluster
    - sql-ag-creation
    - Loadbalancer

## Windows-Cluster:
This role will checks the server connection, installs the failover features in server manager. Then enable firewall rules for not restricting the feature installation and creates cluster with ad and cluster node configuration.

### Workflow description:
- 01_server_connectivity: Uses the powershell module (win_ping) to ping the server.
- 02_install_failover_feature: Uses the powershell module (win_feature) to install Failover-Clustering, RSAT-Clustering, RSAT-Clustering-PowerShell features.
- 03_enable_firewall_rules: Uses the powershell module (win_firewall_rule) to install firewall rules mentioned in vars.yml file
- 04_create_windows_cluster: Checks the cluster existence if already exists and creates the windows cluster by importing failover cluster module.
- 05_configure_ad: Creates the service account, computer object for cluster(CNO) and listener(VCO). Then, Initially it assigns the FC permissions to cluster(CNO) and assigns all FC permissions of Cluster(CNO) to listener(VCO). Finally assign FC permissions of listener(VCO) to computer node object.
- 06_configure_cluster_node: Executes the tasks by include_tasks for adding secondary node to cluster and check cluster status.
- 07_create_vco.yml: Creates the VCO object dynamically with prefix value specified in vars.yml
- 08_disable_cno.yml: Disable the AD account of CNO if exists
- 09_permission_svc_to_cno.yml: Assigns the permissions of service account to CNO object in AD.
- 10_permission_cno_to_VCO.yml: Assigns the permissions of CNO to VCO object in AD.
- 11_permission_VCO_to_node.yml: Assigns the permissions of VCO to node objects in AD.
- add_svc_admin_access.yml: Provides the admin access of service user account.

## storage-cluster:
This role will creates the storage account for file sharing and setting up the witness cluster quorom configuration.

### Workflow description:
- 01_create_storage_account: 
     - This script will checks if storage account already exists.Then creates the storage account and fetch the storage account keys.
     - Second steps, Checks if file share already exists. Then creates the file share by using storage account name and storage account key.
- 02_set_cloud_witness_quorom: 
     - This script will checks the cluster resource which has the resource type as 'Cloud witness'. If exists this cloud witness cluster will set up with storage account name and storage account key.

## sql-cluster:
This role will enable the always on availability group feature and Restart the SQL server services, enables the TCP/IP Port. Then, creates Database.

### Workflow description:
- 01_add_sql_instance_to_cluster: 
     - This script will checks the sql service status, it enables the sql always on feature and restarts the sql services.
- 02_enable_tcp_ip_np: Enable the TCP protocol on the default instance and restarts the SQL server services.
- 03_create_db: Creates the database by importing SQLPS module.

## sql-ag-creation:
This role will takes the backup of DB created in previous process, then it checks the endpoint creation and creates the availability group, joins the secondary replicas to availability group and restores the database in secondary instances, adds the database to secondary replicas and finally checks the health state of availability group and creates the availability group listener.

### Workflow description:
- 01_backup_db.yml
    - This script will takes the backup for data and transaction logs files in the shared folder path existed in primary replica.
- 02_endpoint_creation.yml
    - This script will checks the endpoint already been created in the replicas, if not created it will the endpoint where the value provided in vars.yml.
- 03_ag_creation.yml
    - This script will creates the primary,secondary and tertiary replicas and by these replicas it will creates the availability group.
- 04_join_sec_replicas_to_ag.yml
    - This script will joins the secondary and tertiary replicas to availability group and validates replicas added successfully to availability group.
- 05_restore_db.yml
    - This script will restores the database in secondary and tertiary replicas with data and transaction log files with NO RECOVERY.
- 06_add_db_to_sec_replicas.yml
    - This script will adds the database (availability group database) to secondary and tertiary replicas and validates databases added successfully.
- 07_ag_health_check.yml
    - This script will checks the health status of availability group with status as "Healthy","Error" and "Warning".
- 08_create_ag_listener.yml
    - This script will creates the availability group listener for the availability group created in previous steps. 


## Variables:

### Runtime variables:

- CNO: Cluster Name
- cluster_nodes: Cluster node names used in windows_cluster role.
- cluster_failover_ip: Cluster node failover IP address.
- VCO_prefix: VCO Prefix value for VCO Dynamic creation.
- cno_nodes: Cluster nodes for assiging FC permissions of VCO to CNO Nodes.
- service_account_name: Service account for SQL AG configuration to provice FC Permissions.
- cluster_ou: Provides the domain and computer permissions.
- replica.primary: Primary replica server name.
- replica.secondary: Secondary replica server name.
- replica.tertiary: Tertiary replica server name.
- sql_cluster_nodes: Cluster nodes used for sql-cluster role.
- database.primary: Database name.
- backup_full_path: Backup path.
- backup_log_full_path: Log Backup path.
- db_bkp_share_path: Share path in Cluster nodes.
- availability_group.name: Availability group name.
- availability_group.db_name: Database to create availability group.
- availability_group.endpoint_name: Endpoint name.
- endpoint_name.hadr_port: Port Number.
- AGListenerPort: Availability group listener port number.
- AGListenerName: Availability group listener name.
- AGListenerIP.primary: Primary Instance Listener.
- AGListenerIP.tertiary: Secondary Instance Listener.
- azure_storage.name: Storage account name.
- azure_storage.file_share: Storage account file share name.
- azure_storage.resource_group: Resource group name.
- azure_storage.location: Region name.
- win_clus_firewall_rules.name: Firewall rule name.
- win_clus_firewall_rules.port: Port number.
- win_clus_firewall_rules.protocol: TCP/IP protocol.



       