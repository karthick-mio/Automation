Role Name
=========

storage_cluster_quorum performs below functionality:

  1. Create a storage account and fileshare if not exists,
  2. if exists, it will add to cloud witness cluster quorum 

Requirements
------------

Pre-requisites required for this role:

## Operational Overview:

01_set_cloud_witness_quorum - This playbook task is responsible for adding a storage cluster quorum to an existing SQL Server cluster in Azure using Windows DSC.

 
## Python Package 
    Azure CLI
    
## To install using pip:
    pip install azure-cli==2.39.0
  
## Python package 
    1. pywinrm
    2. pywinrm[kerberos]

## To Install python package:
    pip install pywinrm pywinrm[kerberos]

## Powershell Module
    Failoverclusters

## To Import powershell module in powershell script
    Import-Module FailoverClusters

Role Variables
--------------

## Below are the list of variables that are used in this storage_cluster_quorum role:
    azure_storage:
     name: "testcmpsqlstorage"
     file_share: "cmpfileshare01"
     resource_group: "cv-acceleratesnt-vm-rg"
     location: "eastus"

Dependencies
------------

No dependencies

Example Playbook
----------------

Below is the example code to include the storage-cluster role in the playbook

    - hosts: "{{ hostvars['localhost']['provisioned_hosts'] }}"
      roles:
         - { role: storage-cluster }

License
-------

BSD

Author Information
------------------

suganthanraj.p.contractor@pepsico.com
