# SQL AON Availability Group configuration:

## Overview:

This ansible role automates the enabling of HADR configuration and TCP/IP protocols, Creating database, endpoings and availability group. Then will add the database to availability group, checks the availability group listener and creates the backup in rubrik console.

## Prerequisites
Before executing this role, ensure the following:
- Ansible is installed on the control node.
- Azure CLI is installed and configured.
- The necessary Azure subscription, resource groups, virtual networks, and subnets are available.


## Requirements

### Pre-requisites required for this role:

### Python package 
    1. pywinrm
    2. pywinrm[kerberos]

### To Install python package:
    pip install pywinrm pywinrm[kerberos]

### Powershell module
    Import-Module SQLPS

## DSC Module
  1. ActiveDirectoryDsc
  2. FailoverClusterDsc

## Process for DSC module initialization
  1. Download respective DSC module .nupkg files.
  2. Copy the module unarchiving package from local host.
  3. Paste in provisioned VMs.

- The following variables are set:
  - `domain` - Defines the Environment
  - `service_account_name` - Service account name for execution
  - `Probe port` - Defines the probe port to check listener connectivity.
  - `Tcp Port` - Defines the tcp port to check TCP/IP port connectivity
  - `Backup path` - Defines the backup process for creating availability group creation.
  - `Availability group name` - Defines the availability group name.
  - `AG listener port & IP` - Defines the AGListener Port and IPAddress.
  - `vco` - Defines the listener names.

## Role Structure:

### `0.1_set_facts_based_on_env.yml` 
  - It will set SQL Service Details Based on Domain Environment.
### `01_enable_alwayson.yml` 
  - It will enables always on feature, TCP/IP and restart sql services on all provisioned vms.
### `02_enable_tcp_ip.yml` 
  - It will do TCP/IP and Named Pipes are enabled.
### `03_endpoint_creation.yml` 
  - It will creates endpoint on all provisioned vms.
### `04_create_database.yml` 
  - It will creates the database on primary replica.
### `05_backup_db.yml` 
  - It will take the transaction (.trn) and log (.log) path on mentioned backup path on primary replica.
### `06_ag_creation.yml`
  - It will creates the availability group on primary replica. 
### `07_add_db_to_primary_ag.yml` 
  - It will add the database to availability group on primary replica.
### `08_join_replica.yml` 
  - It will joins the secondary replicas to availability group created.
### `09_restore_database.yml` 
  - It will restores the database on secondary replicas.
### `10_add_db_to_seondary_ag.yml` 
  - It will add the databases to secondary replicas availability group.
### `11_create_listener.yml` 
  - It will create the listener to availability group on primary.
### `12_rubrik_precheck.yml`
  - It will extract the ag name details and resource groups.

## Execution:

### How to Use the Role
Include the following in your playbook to use this role:

```
---
- name: SQL-AON availability group configuration
  hosts: "{{ hostvars['localhost']['provisioned_hosts'] }}"
  roles:
    - { role: sql_server_ag_config }
```
Then, run the playbook using:

Include this role in your playbook and run it using:
```sh
ansible-playbook playbook.yml
```

## Error Handling
- The role captures any failures in sql server always on feature configuration.

## Expected Output
- Successful authentication message.
- Error messages in case of failures.

## Notes
- Ensure all required variables are defined before execution.
- Modify network interface properties as needed based on Azure infrastructure requirements.
- The role is designed to be idempotent, meaning it will not recreate existing resources unnecessarily.

