## Ansible Role for  Windows Failover Cluster Config

## Overview
This Ansible role automates the windows failover cluster configuration and AD functionality.

## Prerequisites
Before executing this role, ensure the following:
- Ansible is installed on the control node.
- Azure CLI is installed and configured.
- The necessary Azure subscription, resource groups, virtual networks, and subnets are available.

## Python package 
  1. pywinrm
  2. pywinrm[kerberos]

## To Install python package:
    pip install pywinrm pywinrm[kerberos]

## Powershell Module
  1. Failoverclusters

## To Import powershell module in powershell script
    Import-Module FailoverClusters

## DSC Module
  1. ActiveDirectoryDsc
  2. FailoverClusterDsc

## Process for DSC module initialization
  1. Download respective DSC module .nupkg files.
  2. Copy the module unarchiving package from local host.
  3. Paste in provisioned VMs.

## Ansible Galaxy Collection    
This role is part of the microsoft.add collection.  To install it, use: ansible-galaxy collection install microsoft.ad.
To use it in a playbook, specify: microsoft.ad.computer

- The following variables are set:
  - `CNO`: Cluster Name
  - `cluster_nodes`: VM Instance Name
  - `cluster_failover_ip`: Cluster Failover IP
  - `user_name`: Service Account Username
  - `password`: Service Account Password
  - `cno_nodes`: VM Hostnames
  - `service_account_name`: Service Account Username
  - `backup_full_path`:  Backup Full Path 
  - `backup_log_full_path`: Transaction Log Full Path
  - `db_bkp_share_path`:  Backup Share Path
  - `share_folder_desc`: Backup Share Path Description

## Role Structure
### 1. 01.1_set_facts_based_on_env.yml 
- It will set SQL Service Details Based on Domain Environment
### 2. 01_install_failover_feature 
- It will check failover windows feature is installed or not
### 3. 02_create_windows_cluster 
- It will create and configure the cluster in windows, check node status whether it is in up or down state and setting up the cluster resource parameter.
### 4. 03_create_vcno 
- check cluster node status, it will check all the cluster node whether it is in up or down state.
### 5. 04_permission_svc_to_cno 
- It will assign the service account permission to cluster created.
### 6. 05_permissions_cno_to_vcno 
- It will assign the Cluster permission to vco listener object created.
### 7. 06_permissions_vcno_to_node 
- It will assign the vco listener object to cluster nodes connected to it.
### 8. 07_share_folder_mount 
- Create the shared folder it not exists.

## Execution

### How to Use the Role
Include the following in your playbook to use this role:

```
---
- name: Windows-Cluster
  hosts: "{{ hostvars['localhost']['provisioned_hosts'] }}"
  roles:
    - { role: windows_failover_cluster }
```

Then, run the playbook using:

Include this role in your playbook and run it using:
```sh
ansible-playbook playbook.yml
```

## Error Handling
- The role captures any failures in windows failover cluster configuration and AD functionality.

## Expected Output
- Successful authentication message.
- Error messages in case of failures.

## Notes
- Ensure all required variables are defined before execution.
- Modify network interface properties as needed based on Azure infrastructure requirements.
- The role is designed to be idempotent, meaning it will not recreate existing resources unnecessarily.
