# Ansible Role for Rubrik Backup configuration

## Overview
This Ansible role automates the Rubrik backup configuration for the primary AG instance using the Rubrik API and GraphQL query.

## Prerequisites
Before executing this role, ensure the following:
- Ansible is installed on the control node.
- Azure CLI is installed and configured.
- The necessary Azure subscription, resource groups, virtual networks, and subnets are available.
- The following variables are set:
  - `host_instance_name`: VM instance name
  - `availability_group_name`: Availability group name
  - Dict variable to fetch the SLA policy name based on cluster details and AG details.

## Role Structure
### 1. Rubrik Backup Configuration
This section ensures authentication with Rubrik API using rubrik credentials:
- Fetch Rubrik URL Based on US Region.
- Connect To The Rubrik Agent To Perform Backup & SLA Assignation.
- Fetch The Tager Cluster UUID.
- Get the SLA ID By SLA Domain Name.
- Get The Host Instance Details By Hostname.
- Fetch The MSSQL AG ID & SLA Assignation Status.
- Assign The SLA Policy To Server Instance and AG.

## Execution

### How to Use the Role
Include the following in your playbook to use this role:

```
---
- name: Rubrik Backup Configuration on Sql AON availability group
  hosts: localhost
  gather_facts: no

  roles:
    - role: sql_aon_rubrik_backup
```

Then, run the playbook using:

Include this role in your playbook and run it using:
```sh
ansible-playbook playbook.yml
```

## Error Handling
- The role captures any failures in rubrik backup and SLA Assignation.
- Failed to to perform rubrik backup & SLA Assignation.

## Expected Output
- Successful authentication message.
- Succefully completed the rubrik backup & SLA Assignation.
- Error messages in case of failures.

## Notes
- Ensure all required variables are defined before execution.
- Modify network interface properties as needed based on Azure infrastructure requirements.
- The role is designed to be idempotent, meaning it will not recreate existing resources unnecessarily.

