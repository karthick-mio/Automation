# Ansible Role for CNO Ip Reservation

## Overview
This Ansible role automates the deployment of network interface cards (NICs) in Azure across High Availability (HA) and Disaster Recovery (DR) regions to reserve ip for cno. It also ensures authentication with Azure CLI using service principal credentials.

## Prerequisites
Before executing this role, ensure the following:
- Ansible is installed on the control node.
- Azure CLI is installed and configured.
- The necessary Azure subscription, resource groups, virtual networks, and subnets are available.
- The following variables are set:
  - `fs_az_client_tenant_id`: Azure tenant ID
  - `fs_az_client_id`: Azure service principal client ID
  - `fs_az_client_secret`: Azure service principal client secret
  - `az_sub_id`: Azure subscription ID
  - `az_vnet_rg_ha`: Resource group for HA region
  - `az_subnet_ha`: Subnet name in HA region
  - `az_vnet_ha`: Virtual network name in HA region
  - `azure_lb_cno_ip_name_primary`: NIC name for HA region
  - `az_vnet_rg_dr`: Resource group for DR region
  - `az_subnet_dr`: Subnet name in DR region
  - `az_vnet_dr`: Virtual network name in DR region
  - `azure_lb_cno_ip_name_secondary_2`: NIC name for DR region

## Role Structure
### 1. Azure CLI Authentication
This section ensures authentication with Azure CLI using service principal credentials:
- Logs in to Azure CLI.
- Sets the Azure subscription.
- Prints a success message upon authentication.
- In case of failure, records error details and fails the execution.

### 2. NIC Deployment in HA Region
This section:
- Creates a NIC in the HA region with dynamic IP allocation.
- Updates the NIC with a static IP address.
- Stores the allocated static IP address.
- Prints a success message upon completion.
- Handles errors and prints failure messages if any issue occurs.

### 3. NIC Deployment in DR Region
This section:
- Creates a NIC in the DR region with dynamic IP allocation.
- Updates the NIC with a static IP address.
- Stores the allocated static IP address.
- Prints a success message upon completion.
- Handles errors and prints failure messages if any issue occurs.

## Execution

### How to Use the Role
Include the following in your playbook to use this role:

```
---
- name: Create Nic Card to Reserve Ip for CNO
  hosts: localhost
  gather_facts: no
  vars_files:
    - vars.yml

  roles:
    - role: sql_aon_cno_ip_reservation
```

Then, run the playbook using:

Include this role in your playbook and run it using:
```sh
ansible-playbook playbook.yml
```

## Error Handling
- The role captures any failures in Azure CLI authentication and NIC deployment.
- If authentication fails, error details are stored in failure artifacts, and execution stops.
- If NIC creation or update fails, an error message is displayed, but the execution continues.

## Expected Output
- Successful authentication message.
- NIC creation and static IP allocation confirmation for both HA and DR regions.
- Stored static IP addresses for further configuration.
- Error messages in case of failures.

## Notes
- Ensure all required variables are defined before execution.
- Modify network interface properties as needed based on Azure infrastructure requirements.
- The role is designed to be idempotent, meaning it will not recreate existing resources unnecessarily.

